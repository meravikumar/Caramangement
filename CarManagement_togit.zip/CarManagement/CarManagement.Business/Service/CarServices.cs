﻿using CarManagement.Business.IServices;
using CarManagement.Core.ViewModels.CarDetails;
using CarManagement.Core.ViewModels.Cars;
using CarManagement.Data.IRepository;
using CarManagement.Data.Models;
using CarManagement.Data.Repository;

namespace CarManagement.Business.Service
{
    public class CarServices : ICarService
    {
        private readonly ICarRepository<Car> _carRepository;
        private readonly ICompanyRepository<Company> _companyRepository;
        private readonly ICarDetailsRepository<CarDetails> _carDetailRepository;
        private readonly ICompanyService _companyService;
        public CarServices(ICarRepository<Car>carRepository,
            ICompanyRepository<Company> companyRepository,
            ICarDetailsRepository<CarDetails> carDetailsRepository,
            ICompanyService companyService)
        {
            _carRepository = carRepository;
            _companyRepository = companyRepository;
            _carDetailRepository = carDetailsRepository;
            _companyService = companyService;
        }
        public Task<CarVM> AddCarAsync(int companyId, CarVM carVM)
        {
            throw new NotImplementedException();
        }

        public async Task<Car> CreateCarAsync(CreateCarVM createCarVM)
        {
            var company = _companyService.GetCompanyAsyncByID(createCarVM.CompanyId);
            if (company == null)
            {
                return null;

            }

            var car = new Car()
            {
                CarName= createCarVM.CarName,
                CarModel= createCarVM.CarModel,
                Insurance= createCarVM.Insurance,
                Price= createCarVM.Price,
                CompanyId= createCarVM.CompanyId,

            };
            if(createCarVM.CarModel == null)
            {
                return null;
            }
            
            await _carRepository.AddCarAsync(car);
            return car;
        }

        public Task<bool> DeleteCarAsync(int companyId, int carId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteCompanyAsync(int companyId)
        {
            throw new NotImplementedException();
        }

        public async Task<List<CarListVM>> GetAllCarsAsync()
        {
            var cars = await _carRepository.GetAllCarAsync();
            var companies = await _companyRepository.GetAllAsync();

            // Map cars to CarListVM
            var vms = cars.Select(car =>
            {
                // Find the company associated with the car
                var company = companies.FirstOrDefault(c => c.CompanyId == car.CompanyId);

                return new CarListVM
                {
                    CarId = car.CarId,
                    CarName = car.CarName,
                    Price = car.Price,
                    CarModel = car.CarModel,
                    Insurance = car.Insurance,
                    Company = company != null ? company.CompanyName : null 
                };
            }).ToList();

            return vms;
        }

        public async Task<CarByIdWithDetailsVM> GetCarByIdAsync(int carId)
        {
            var car = await _carRepository.GetCarByIdAsync(carId);
            var cardetails = await _carDetailRepository.GetCarDetailsByCarId(carId);

            if (car == null)
            {
                return null;
            }
            if(cardetails == null)
            {
                return null;
            }
            // Map the retrieved data to CarWithDetailVM
            var carVM = new CarByIdWithDetailsVM
            {
                CarId = car.CarId,
                CarName = car.CarName,
                Price = car.Price,
                CarModel = car.CarModel,
                Insurance = car.Insurance,
                CarDetail = new CarDetailVM
                {
                    CarDetail_Id=cardetails.CarDetail_Id,
                    Engine = cardetails.Engine,
                    NumberOfAirbags = cardetails.NumberOfAirbags,
                    SafetRating = cardetails.SafetRating,
                    Type = cardetails.Type,
                    Weight = cardetails.Weight
                }
            };
            return carVM;
        }

        public Task<CarVM> GetCompanyAsync(int companyId)
        {
            throw new NotImplementedException();
        }

        public Task<CarVM> UpdateCarAsync(int companyId, int carId, CarVM carVM)
        {
            throw new NotImplementedException();
        }

        public Task<CarVM> UpdateCompanyAsync(int companyId, CarVM companyVM)
        {
            throw new NotImplementedException();
        }
    }
}
