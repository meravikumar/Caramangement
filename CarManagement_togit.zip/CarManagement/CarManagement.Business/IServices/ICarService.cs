﻿using CarManagement.Core.ViewModels.Cars;
using CarManagement.Data.Models;

namespace CarManagement.Business.IServices
{
    public interface ICarService
    {
        Task<CarByIdWithDetailsVM> GetCarByIdAsync(int carId);
        Task<List<CarListVM>> GetAllCarsAsync();
        Task<CarVM> UpdateCompanyAsync(int carId, CarVM carVM);
        Task<bool> DeleteCompanyAsync(int carId);
        Task<CarVM> AddCarAsync(int carId, CarVM carVM);
        Task<CarVM> UpdateCarAsync(int companyId, int carId, CarVM carVM);
        Task<bool> DeleteCarAsync(int companyId, int carId);
        Task<Car> CreateCarAsync(CreateCarVM createCarVM);
    }
}
