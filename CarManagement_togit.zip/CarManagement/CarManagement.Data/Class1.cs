﻿namespace CarManagement.Data
{
    public class Class1
    {

    }
}
