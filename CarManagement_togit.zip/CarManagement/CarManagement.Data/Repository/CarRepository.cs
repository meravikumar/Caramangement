﻿using CarManagement.Data.Context;
using CarManagement.Data.IRepository;
using CarManagement.Data.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace CarManagement.Data.Repository
{
    public class CarRepository<TEntity> : ICarRepository<TEntity> where TEntity : class
    {
        private readonly CarManagementContext _context;
        private readonly DbSet<TEntity> _dbSet;

        public CarRepository(CarManagementContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbSet = _context.Set<TEntity>();
        }
        public async Task<TEntity> AddCarAsync(TEntity entity)
        {
            
            await _dbSet.AddAsync(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public Task<bool> DeleteAsync(TEntity entity)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<TEntity>> GetAllCarAsync()
        {
            return await _dbSet.ToListAsync();
        }

       public async Task<List<Car>> GetCarByCompanyIdAsync(int id)
        {
            var result= _context.Cars.Where(c=>c.CompanyId==id).ToList();
            return result;
                
        }

        public async Task<TEntity> GetCarByIdAsync(int id)
        {
            return await _dbSet.FindAsync(id);
        }

        public Task<TEntity> UpdateAsync(TEntity entity)
        {
            throw new NotImplementedException();
        }

        

       
    }
}
