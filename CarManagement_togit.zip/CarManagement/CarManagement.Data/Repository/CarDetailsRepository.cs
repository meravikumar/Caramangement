﻿using CarManagement.Data.Context;
using CarManagement.Data.IRepository;
using CarManagement.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Data.Repository
{
    public class CarDetailsRepository<TEntity> : ICarDetailsRepository<TEntity> where TEntity : class
    {
        private readonly CarManagementContext _context;
        private readonly DbSet<TEntity> _dbSet;

        public CarDetailsRepository(CarManagementContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbSet = _context.Set<TEntity>();
        }

        public async Task<CarDetails> GetCarDetailsByCarId(int id)
        {
            var carDetails = await _context.Details.FirstOrDefaultAsync(cd => cd.CarId == id);

            if (carDetails == null)
            {
                throw new InvalidOperationException($"Car details with ID {id} not found.");
            }

            return carDetails;
        }
    }
}
