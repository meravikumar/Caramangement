﻿using CarManagement.Data.Models;
using System.Linq.Expressions;

namespace CarManagement.Data.IRepository
{
    public interface ICarRepository<TEntity> where TEntity : class
    {
        Task<List<Car>> GetCarByCompanyIdAsync(int id);
        Task<IEnumerable<TEntity>> GetAllCarAsync();
        Task<TEntity> GetCarByIdAsync(int id);
        Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> AddCarAsync(TEntity entity);
        Task<TEntity> UpdateAsync(TEntity entity);
        Task<bool> DeleteAsync(TEntity entity);
    }
}
