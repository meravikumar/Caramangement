﻿namespace CarManagement.Core.ViewModels.Cars
{
    public class CarVM
    {
        public int CarId { get; set; }
        public string CarName { get; set; }
        public decimal Price { get; set; }
        public string CarModel { get; set; }
        public bool Insurance { get; set; }
    }
}
