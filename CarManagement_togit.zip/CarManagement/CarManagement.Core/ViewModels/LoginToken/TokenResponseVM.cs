﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Core.ViewModels.LoginToken
{
    public class TokenResponseVM
    {
        public string AccessToken { get; set; }
    }
}
