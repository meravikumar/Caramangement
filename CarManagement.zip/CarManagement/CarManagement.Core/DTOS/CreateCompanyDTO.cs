﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Core.DTOS
{
    public class CreateCompanyDTO
    {
        public string CompanyName { get; set; }
        public string Location { get; set; }
        public string CEO { get; set; }
        public bool IsFinanceProvider { get; set; }
        public DateOnly EstablishedDate { get; set; }=DateOnly.MinValue;
    }
}
