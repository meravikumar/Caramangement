﻿using CarManagement.Core.DTOS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Business.IServices
{
    public interface ICarService
    {
        Task<CarDTO> GetCompanyAsync(int carId);
        Task<CarDTO> CreateCompanyAsync(CarDTO carId);
        Task<CarDTO> UpdateCompanyAsync(int carId, CarDTO carDTO);
        Task<bool> DeleteCompanyAsync(int carId);
        Task<CarDTO> AddCarAsync(int carId, CarDTO carDTO);
        Task<CarDTO> UpdateCarAsync(int companyId, int carId, CarDTO carDTO);
        Task<bool> DeleteCarAsync(int companyId, int carId);
    }
}
