﻿using CarManagement.Core.DTOS;
using CarManagement.Core.ViewModel;

namespace CarManagement.Business.IServices
{
    public interface IUserAuthService
    {
        APIResponseDTO<TokenResponseDTO> Login(LoginViewModel loginViewModel);
    }

}
