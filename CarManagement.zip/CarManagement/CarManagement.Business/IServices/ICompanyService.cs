﻿using CarManagement.Core.DTOS;
using CarManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Business.IServices
{
    public interface ICompanyService
    {
        Task<CompanyDTO> GetCompanyAsync(int companyId);
        Task<Company> CreateCompanyAsync(CreateCompanyDTO createCompanyDTO);
        Task<CompanyDTO> UpdateCompanyAsync(int companyId, CompanyDTO companyDTO);
        Task<bool> DeleteCompanyAsync(int companyId);
        Task<CarDTO> AddCarAsync(int companyId, CarDTO carDTO);
        Task<CarDTO> UpdateCarAsync(int companyId, int carId, CarDTO carDTO);
        Task<bool> DeleteCarAsync(int companyId, int carId);

    }
}
