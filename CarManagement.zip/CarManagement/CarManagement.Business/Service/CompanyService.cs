﻿using CarManagement.Business.IServices;
using CarManagement.Core.DTOS;
using CarManagement.Data.IRepository;
using CarManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Business.Service
{
    public class CompanyService:ICompanyService
    {
        private readonly ICompanyRepository<Company> _companyRepository;
        private readonly ICarRepository<Car> _carRepository;
         

        public CompanyService(ICompanyRepository<Company> companyRepository, ICarRepository<Car> carRepository)
        {
            _companyRepository = companyRepository;
            _carRepository = carRepository; 
        }


        public async Task<CompanyDTO> GetCompanyAsync(int companyId)
{
    var company = await _companyRepository.GetByIdAsync(companyId);
     var car = await _carRepository.GetByIdAsync(companyId); 
    if (company == null)
        return null;

    // Ensure that company.Cars is not null before selecting car DTOs
    if (company.Cars == null)
        company.Cars = new List<Car>();

    return new CompanyDTO
    {
        CompanyId = company.CompanyId,
        CompanyName = company.CompanyName,
        Location = company.Location,
        CEO = company.CEO,
        IsFinanceProvider = company.IsFinanceProvider,
        EstablishedDate = company.EstablishedDate,
        Cars = company.Cars.Select(c => new CarDTO
        {
            CarId = c.CarId,
            CarName = c.CarName,
            Price = c.Price,
            CarModel = c.CarModel,
            Insurance = c.Insurance
        }).ToList()
    };
}


        public async Task<Company> CreateCompanyAsync(CreateCompanyDTO createCompanyDTO)
        {
            var company = new Company
            {
                CompanyName = createCompanyDTO.CompanyName,
                Location = createCompanyDTO.Location,
                CEO = createCompanyDTO.CEO,
                IsFinanceProvider = createCompanyDTO.IsFinanceProvider,
                EstablishedDate = createCompanyDTO.EstablishedDate
            };

            await _companyRepository.AddAsync(company);

            return company; 
        }

        public async Task<CompanyDTO> UpdateCompanyAsync(int companyId, CompanyDTO companyDTO)
        {
            var existingCompany = await _companyRepository.GetByIdAsync(companyId);
            if (existingCompany == null)
                return null; // Company not found

            existingCompany.CompanyName = companyDTO.CompanyName;
            existingCompany.Location = companyDTO.Location;
            existingCompany.CEO = companyDTO.CEO;
            existingCompany.IsFinanceProvider = companyDTO.IsFinanceProvider;
            existingCompany.EstablishedDate = companyDTO.EstablishedDate;

            await _companyRepository.UpdateAsync(existingCompany);

            return companyDTO; // You may want to return the updated company
        }

        public async Task<bool> DeleteCompanyAsync(int companyId)
        {
            var existingCompany = await _companyRepository.GetByIdAsync(companyId);
            if (existingCompany == null)
                return false; // Company not found

            await _companyRepository.DeleteAsync(existingCompany);

            return true; // Company deleted successfully
        }

        public async Task<CarDTO> AddCarAsync(int companyId, CarDTO carDTO)
        {
            var company = await _companyRepository.GetByIdAsync(companyId);
            if (company == null)
                return null; // Company not found

            var car = new Car
            {
                CarName = carDTO.CarName,
                Price = carDTO.Price,
                CarModel = carDTO.CarModel,
                Insurance = carDTO.Insurance
            };

            company.Cars.Add(car);
            await _companyRepository.UpdateAsync(company);

            return carDTO; // You may want to return the newly added car
        }

        public async Task<CarDTO> UpdateCarAsync(int companyId, int carId, CarDTO carDTO)
        {
            var company = await _companyRepository.GetByIdAsync(companyId);
            if (company == null)
                return null; // Company not found

            var existingCar = company.Cars.FirstOrDefault(c => c.CarId == carId);
            if (existingCar == null)
                return null; // Car not found

            existingCar.CarName = carDTO.CarName;
            existingCar.Price = carDTO.Price;
            existingCar.CarModel = carDTO.CarModel;
            existingCar.Insurance = carDTO.Insurance;

            await _companyRepository.UpdateAsync(company);

            return carDTO; // You may want to return the updated car
        }

        public async Task<bool> DeleteCarAsync(int companyId, int carId)
        {
            var company = await _companyRepository.GetByIdAsync(companyId);
            if (company == null)
                return false; // Company not found

            var existingCar = company.Cars.FirstOrDefault(c => c.CarId == carId);
            if (existingCar == null)
                return false; // Car not found

            company.Cars.Remove(existingCar);
            await _companyRepository.UpdateAsync(company);

            return true; // Car deleted successfully
        }
    }
}
