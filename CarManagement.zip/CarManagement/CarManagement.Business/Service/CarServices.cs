﻿using CarManagement.Business.IServices;
using CarManagement.Core.DTOS;
using CarManagement.Data.IRepository;
using CarManagement.Data.Models;
using CarManagement.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Business.Service
{
    public class CarServices : ICarService
    {
        private readonly ICarRepository<Car> _carRepository;
        public CarServices(ICarRepository<Car> carRepository)
        {
            _carRepository = carRepository;
        }
        public Task<CarDTO> AddCarAsync(int companyId, CarDTO carDTO)
        {
            throw new NotImplementedException();
        }

        public Task<CarDTO> CreateCompanyAsync(CarDTO companyDTO)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteCarAsync(int companyId, int carId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteCompanyAsync(int companyId)
        {
            throw new NotImplementedException();
        }

        public Task<CarDTO> GetCompanyAsync(int companyId)
        {
            throw new NotImplementedException();
        }

        public Task<CarDTO> UpdateCarAsync(int companyId, int carId, CarDTO carDTO)
        {
            throw new NotImplementedException();
        }

        public Task<CarDTO> UpdateCompanyAsync(int companyId, CarDTO companyDTO)
        {
            throw new NotImplementedException();
        }
    }
}
