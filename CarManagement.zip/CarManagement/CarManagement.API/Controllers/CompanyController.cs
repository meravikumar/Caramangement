﻿using CarManagement.Business.IServices;
using CarManagement.Core.DTOS;
using Microsoft.AspNetCore.Mvc;

namespace CarManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyService _companyService;

        public CompanyController(ICompanyService companyService)
        {
            _companyService = companyService;
        }

        [HttpGet("{companyId}")]
        public async Task<IActionResult> GetCompany(int companyId)
        {
            var companyDTO = await _companyService.GetCompanyAsync(companyId);
            if (companyDTO == null)
                return NotFound();
            return Ok(companyDTO);
        }

        [HttpPost]
        public async Task<IActionResult> CreateCompany([FromBody] CreateCompanyDTO companyDTO)
        {
            var createdCompany = await _companyService.CreateCompanyAsync(companyDTO);
            // CreatedAtAction(nameof(GetCompany), new { companyId = createdCompany.CompanyId }, createdCompany);
            return Ok(createdCompany);
        }   

        [HttpPut("{companyId}")]
        public async Task<IActionResult> UpdateCompany(int companyId, [FromBody] CompanyDTO companyDTO)
        {
            var updatedCompany = await _companyService.UpdateCompanyAsync(companyId, companyDTO);
            if (updatedCompany == null)
                return NotFound();
            return Ok(updatedCompany);
        }

        [HttpDelete("{companyId}")]
        public async Task<IActionResult> DeleteCompany(int companyId)
        {
            var result = await _companyService.DeleteCompanyAsync(companyId);
            if (!result)
                return NotFound();
            return NoContent();
        }

        [HttpPost("{companyId}/cars")]
        public async Task<IActionResult> AddCar(int companyId, [FromBody] CarDTO carDTO)
        {
            var addedCar = await _companyService.AddCarAsync(companyId, carDTO);
            if (addedCar == null)
                return NotFound();
            return CreatedAtAction(nameof(GetCompany), new { companyId = companyId, carId = addedCar.CarId }, addedCar);
        }

        [HttpPut("{companyId}/cars/{carId}")]
        public async Task<IActionResult> UpdateCar(int companyId, int carId, [FromBody] CarDTO carDTO)
        {
            var updatedCar = await _companyService.UpdateCarAsync(companyId, carId, carDTO);
            if (updatedCar == null)
                return NotFound();
            return Ok(updatedCar);
        }

        [HttpDelete("{companyId}/cars/{carId}")]
        public async Task<IActionResult> DeleteCar(int companyId, int carId)
        {
            var result = await _companyService.DeleteCarAsync(companyId, carId);
            if (!result)
                return NotFound();
            return NoContent();
        }
    }
}
